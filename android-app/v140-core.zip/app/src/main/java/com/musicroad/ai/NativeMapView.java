package com.musicroad.ai;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.location.Location;
import android.view.View;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public final class NativeMapView extends View {
    private final Paint grid=new Paint(1),routePaint=new Paint(1),dot=new Paint(1),hazardPaint=new Paint(1),label=new Paint(1);
    private final List<double[]> route=new ArrayList<>(),hazards=new ArrayList<>(); private double currentLat=Double.NaN,currentLon=Double.NaN;
    public NativeMapView(Context c){super(c);setBackgroundColor(Color.rgb(8,13,19));grid.setColor(Color.rgb(22,32,43));grid.setStrokeWidth(dp(1));routePaint.setColor(Color.rgb(40,231,255));routePaint.setStrokeWidth(dp(5));routePaint.setStyle(Paint.Style.STROKE);routePaint.setStrokeCap(Paint.Cap.ROUND);routePaint.setStrokeJoin(Paint.Join.ROUND);dot.setColor(Color.rgb(255,122,26));hazardPaint.setColor(Color.rgb(255,70,92));label.setColor(Color.rgb(139,158,173));label.setTextSize(dp(12));}
    private float dp(float v){return v*getResources().getDisplayMetrics().density;}
    public void setRoute(JSONArray coords){route.clear();if(coords!=null)for(int i=0;i<coords.length();i++){JSONArray p=coords.optJSONArray(i);if(p!=null&&p.length()>=2)route.add(new double[]{p.optDouble(1),p.optDouble(0)});}invalidate();}
    public void setHazards(JSONArray a){hazards.clear();if(a!=null)for(int i=0;i<a.length();i++){JSONObject j=a.optJSONObject(i);if(j==null)continue;double lat=j.optDouble("latitude",j.optDouble("lat",Double.NaN));double lon=j.optDouble("longitude",j.optDouble("lon",Double.NaN));if(!Double.isNaN(lat)&&!Double.isNaN(lon))hazards.add(new double[]{lat,lon});}invalidate();}
    public void setPosition(Location l){if(l!=null){currentLat=l.getLatitude();currentLon=l.getLongitude();invalidate();}}
    @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();for(int i=1;i<8;i++){float x=w*i/8f;c.drawLine(x,0,x,h,grid);}for(int i=1;i<8;i++){float y=h*i/8f;c.drawLine(0,y,w,y,grid);}Bounds b=bounds();if(b==null){c.drawText("MAPA NATIVO · inicie uma viagem para ver a rota",dp(18),dp(30),label);return;}Path p=new Path();boolean first=true;for(double[] q:route){float[] xy=map(q[0],q[1],b,w,h);if(first){p.moveTo(xy[0],xy[1]);first=false;}else p.lineTo(xy[0],xy[1]);}c.drawPath(p,routePaint);for(double[] q:hazards){float[] xy=map(q[0],q[1],b,w,h);c.drawCircle(xy[0],xy[1],dp(6),hazardPaint);}if(!Double.isNaN(currentLat)){float[] xy=map(currentLat,currentLon,b,w,h);c.drawCircle(xy[0],xy[1],dp(9),dot);c.drawCircle(xy[0],xy[1],dp(15),stroke(Color.argb(90,255,122,26)));}}
    private Paint stroke(int color){Paint p=new Paint(1);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(3));p.setColor(color);return p;}
    private Bounds bounds(){if(route.isEmpty()&&Double.isNaN(currentLat))return null;double minLat=90,maxLat=-90,minLon=180,maxLon=-180;for(double[] q:route){minLat=Math.min(minLat,q[0]);maxLat=Math.max(maxLat,q[0]);minLon=Math.min(minLon,q[1]);maxLon=Math.max(maxLon,q[1]);}for(double[] q:hazards){minLat=Math.min(minLat,q[0]);maxLat=Math.max(maxLat,q[0]);minLon=Math.min(minLon,q[1]);maxLon=Math.max(maxLon,q[1]);}if(!Double.isNaN(currentLat)){minLat=Math.min(minLat,currentLat);maxLat=Math.max(maxLat,currentLat);minLon=Math.min(minLon,currentLon);maxLon=Math.max(maxLon,currentLon);}if(maxLat-minLat<.002){maxLat+=.001;minLat-=.001;}if(maxLon-minLon<.002){maxLon+=.001;minLon-=.001;}return new Bounds(minLat,maxLat,minLon,maxLon);}
    private float[] map(double lat,double lon,Bounds b,float w,float h){float pad=dp(24);float x=pad+(float)((lon-b.minLon)/(b.maxLon-b.minLon))*(w-2*pad);float y=h-pad-(float)((lat-b.minLat)/(b.maxLat-b.minLat))*(h-2*pad);return new float[]{x,y};}
    private static final class Bounds{final double minLat,maxLat,minLon,maxLon;Bounds(double a,double b,double c,double d){minLat=a;maxLat=b;minLon=c;maxLon=d;}}
}
