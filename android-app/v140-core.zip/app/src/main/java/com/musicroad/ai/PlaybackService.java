package com.musicroad.ai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;

public final class PlaybackService extends Service {
    public static final String ACTION_PLAY="com.musicroad.ai.PLAY";
    public static final String ACTION_TOGGLE="com.musicroad.ai.TOGGLE";
    public static final String ACTION_STOP="com.musicroad.ai.STOP";
    public static final String ACTION_STATE="com.musicroad.ai.PLAYBACK_STATE";
    public static final String EXTRA_URI="uri",EXTRA_TITLE="title",EXTRA_ARTIST="artist";
    private static final String CHANNEL="musicroad_playback";
    private MediaPlayer player; private String title="Nenhuma música",artist="";

    @Override public void onCreate(){super.onCreate();createChannel();}
    @Override public int onStartCommand(Intent i,int flags,int startId){
        if(i==null)return START_NOT_STICKY;String action=i.getAction();
        if(ACTION_PLAY.equals(action)){play(i.getStringExtra(EXTRA_URI),i.getStringExtra(EXTRA_TITLE),i.getStringExtra(EXTRA_ARTIST));}
        else if(ACTION_TOGGLE.equals(action)){toggle();}
        else if(ACTION_STOP.equals(action)){stopPlayback();stopSelf();}
        return START_NOT_STICKY;
    }
    private void play(String uri,String t,String a){
        if(uri==null||uri.trim().isEmpty())return;stopPlayback();title=t==null?"Música":t;artist=a==null?"":a;
        try{
            player=new MediaPlayer();player.setAudioAttributes(new AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build());
            player.setDataSource(this, Uri.parse(uri));player.setOnPreparedListener(mp->{mp.start();foreground();broadcast();});player.setOnCompletionListener(mp->{broadcast();stopForeground(false);});player.prepareAsync();foreground();
        }catch(Exception e){stopPlayback();}
    }
    private void toggle(){if(player==null)return;if(player.isPlaying())player.pause();else player.start();foreground();broadcast();}
    private void stopPlayback(){if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}broadcast();}
    private boolean playing(){return player!=null&&player.isPlaying();}
    private void broadcast(){Intent b=new Intent(ACTION_STATE);b.setPackage(getPackageName());b.putExtra("title",title);b.putExtra("artist",artist);b.putExtra("playing",playing());sendBroadcast(b);}
    private void foreground(){startForeground(77,notification());}
    private Notification notification(){
        Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent tog=new Intent(this,PlaybackService.class).setAction(ACTION_TOGGLE);PendingIntent tp=PendingIntent.getService(this,1,tog,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        b.setSmallIcon(com.musicroad.ai.R.drawable.ic_notification).setContentTitle(title).setContentText(artist.trim().isEmpty()?"MusicRoad":artist).setContentIntent(pi).setOngoing(playing()).addAction(0,playing()?"Pausar":"Tocar",tp);
        return b.build();
    }
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"Player MusicRoad",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(c);}}
    @Override public void onDestroy(){stopPlayback();super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
