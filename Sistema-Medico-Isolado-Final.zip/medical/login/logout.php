<?php
require_once __DIR__ . '/../api/bootstrap.php';

if (current_medico()) {
    audit_log('logout', 'medicos', $_SESSION['medico_id'], ['ip' => $_SERVER['REMOTE_ADDR']]);
}

// Unset all of the session variables.
$_SESSION = array();

// If it's desired to kill the session, also delete the session cookie.
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

session_destroy();
header('Location: index.php');
die();
